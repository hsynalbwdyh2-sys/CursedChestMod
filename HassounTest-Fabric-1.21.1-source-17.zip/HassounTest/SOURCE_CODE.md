# Hassoun Test — complete project source files

Minecraft Java 1.21.1 / Fabric / Java 21


This is a convenience listing. The real files are also included in their project paths in the ZIP.


## `src/main/java/com/hassoun/test/HassounChestBlock.java`

```java
package com.hassoun.test;

import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class HassounChestBlock extends BlockWithEntity {
    public HassounChestBlock(Settings settings) { super(settings); }

    @Override
    public @Nullable BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new HassounChestBlockEntity(pos, state);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient && world.getBlockEntity(pos) instanceof HassounChestBlockEntity chest) {
            player.openHandledScreen(chest);
        }
        return ActionResult.SUCCESS;
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }
}
```


## `src/main/java/com/hassoun/test/HassounChestBlockEntity.java`

```java
package com.hassoun.test;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;

public class HassounChestBlockEntity extends BlockEntity implements Inventory, ExtendedScreenHandlerFactory {
    private final DefaultedList<ItemStack> items = DefaultedList.ofSize(54, ItemStack.EMPTY);

    public HassounChestBlockEntity(BlockPos pos, BlockState state) {
        super(HassounTest.CHEST_BLOCK_ENTITY, pos, state);
    }

    @Override public int size() { return items.size(); }
    @Override public boolean isEmpty() { return items.stream().allMatch(ItemStack::isEmpty); }
    @Override public ItemStack getStack(int slot) { return items.get(slot); }
    @Override public ItemStack removeStack(int slot, int amount) { ItemStack result = Inventories.splitStack(items, slot, amount); if (!result.isEmpty()) markDirty(); return result; }
    @Override public ItemStack removeStack(int slot) { ItemStack result = Inventories.removeStack(items, slot); if (!result.isEmpty()) markDirty(); return result; }
    @Override public void setStack(int slot, ItemStack stack) { items.set(slot, stack); if (stack.getCount() > getMaxCountPerStack()) stack.setCount(getMaxCountPerStack()); markDirty(); }
    @Override public boolean canPlayerUse(PlayerEntity player) { return !isRemoved() && player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0; }
    @Override public void clear() { items.clear(); markDirty(); }
    @Override public void markDirty() { super.markDirty(); }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.readNbt(nbt, registries);
        Inventories.readNbt(nbt, items, registries);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.writeNbt(nbt, registries);
        Inventories.writeNbt(nbt, items, registries);
    }

    @Override public Text getDisplayName() { return Text.translatable("container.hassountest.hassoun_iron_chest"); }
    @Override public void writeScreenOpeningData(ServerPlayerEntity player, RegistryByteBuf buf) { buf.writeBlockPos(pos); }
    @Override public ScreenHandler createMenu(int syncId, PlayerInventory playerInventory, PlayerEntity player) {
        return new HassounChestScreenHandler(syncId, playerInventory, this);
    }
}
```


## `src/main/java/com/hassoun/test/HassounChestScreen.java`

```java
package com.hassoun.test;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class HassounChestScreen extends HandledScreen<HassounChestScreenHandler> {
    private static final Identifier TEXTURE = Identifier.ofVanilla("textures/gui/container/generic_54.png");

    public HassounChestScreen(HassounChestScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundHeight = 222;
        this.playerInventoryTitleY = this.backgroundHeight - 94;
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        context.drawTexture(TEXTURE, x, y, 0, 0, backgroundWidth, 6 * 18 + 17);
        context.drawTexture(TEXTURE, x, y + 6 * 18 + 17, 0, 126, backgroundWidth, 96);
    }
}
```


## `src/main/java/com/hassoun/test/HassounChestScreenHandler.java`

```java
package com.hassoun.test;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

public class HassounChestScreenHandler extends ScreenHandler {
    private final Inventory inventory;

    public HassounChestScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, new net.minecraft.inventory.SimpleInventory(54));
    }

    public HassounChestScreenHandler(int syncId, PlayerInventory playerInventory, Inventory inventory) {
        super(HassounTest.CHEST_SCREEN_HANDLER, syncId);
        checkSize(inventory, 54);
        this.inventory = inventory;
        inventory.onOpen(playerInventory.player);
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 198));
        }
    }

    @Override public boolean canUse(PlayerEntity player) { return inventory.canPlayerUse(player); }

    @Override
    public net.minecraft.item.ItemStack quickMove(PlayerEntity player, int slotIndex) {
        net.minecraft.item.ItemStack newStack = net.minecraft.item.ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (slot != null && slot.hasStack()) {
            net.minecraft.item.ItemStack original = slot.getStack();
            newStack = original.copy();
            if (slotIndex < 54) {
                if (!insertItem(original, 54, slots.size(), true)) return net.minecraft.item.ItemStack.EMPTY;
            } else if (!insertItem(original, 0, 54, false)) {
                return net.minecraft.item.ItemStack.EMPTY;
            }
            if (original.isEmpty()) slot.setStack(net.minecraft.item.ItemStack.EMPTY);
            else slot.markDirty();
        }
        return newStack;
    }

    @Override public void onClosed(PlayerEntity player) { super.onClosed(player); inventory.onClose(player); }
}
```


## `src/main/java/com/hassoun/test/HassounTest.java`

```java
package com.hassoun.test;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HassounTest implements ModInitializer {
    public static final String MOD_ID = "hassountest";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final Block HASSoUN_IRON_CHEST = new HassounChestBlock(
            AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(3.0F).requiresTool()
    );
    public static BlockEntityType<HassounChestBlockEntity> CHEST_BLOCK_ENTITY;
    public static final net.minecraft.screen.ScreenHandlerType<HassounChestScreenHandler> CHEST_SCREEN_HANDLER =
            Registry.register(Registries.SCREEN_HANDLER, id("hassoun_chest"),
                    new net.minecraft.screen.ScreenHandlerType<>(HassounChestScreenHandler::new,
                            net.minecraft.resource.featuretoggle.FeatureFlags.VANILLA_FEATURES));

    @Override
    public void onInitialize() {
        Registry.register(Registries.BLOCK, id("hassoun_iron_chest"), HASSoUN_IRON_CHEST);
        Registry.register(Registries.ITEM, id("hassoun_iron_chest"),
                new BlockItem(HASSoUN_IRON_CHEST, new Item.Settings()));
        CHEST_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("hassoun_iron_chest"),
                BlockEntityType.Builder.create(HassounChestBlockEntity::new, HASSoUN_IRON_CHEST).build());
        LOGGER.info("Hassoun Test loaded: Hassoun Iron Chest registered.");
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
```


## `src/main/java/com/hassoun/test/HassounTestClient.java`

```java
package com.hassoun.test;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public final class HassounTestClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(HassounTest.CHEST_SCREEN_HANDLER, HassounChestScreen::new);
    }
}
```


## `src/main/resources/assets/hassountest/blockstates/hassoun_iron_chest.json`

```json
{"variants":{"":{"model":"hassountest:block/hassoun_iron_chest"}}}
```


## `src/main/resources/assets/hassountest/lang/ar_sa.json`

```json
{"block.hassountest.hassoun_iron_chest":"صندوق حسون الحديدي","container.hassountest.hassoun_iron_chest":"صندوق حسون الحديدي"}
```


## `src/main/resources/assets/hassountest/lang/en_us.json`

```json
{"block.hassountest.hassoun_iron_chest":"Hassoun Iron Chest","container.hassountest.hassoun_iron_chest":"Hassoun Iron Chest"}
```


## `src/main/resources/assets/hassountest/models/block/hassoun_iron_chest.json`

```json
{"parent":"minecraft:block/cube_all","textures":{"all":"minecraft:block/iron_block"}}
```


## `src/main/resources/assets/hassountest/models/item/hassoun_iron_chest.json`

```json
{"parent":"hassountest:block/hassoun_iron_chest"}
```


## `src/main/resources/data/hassountest/loot_tables/blocks/hassoun_iron_chest.json`

```json
{
  "type": "minecraft:block",
  "pools": [{
    "rolls": 1,
    "entries": [{"type": "minecraft:item", "name": "hassountest:hassoun_iron_chest"}],
    "conditions": [{"condition": "minecraft:survives_explosion"}]
  }]
}
```


## `src/main/resources/data/hassountest/recipes/hassoun_iron_chest.json`

```json
{
  "type": "minecraft:crafting_shaped",
  "pattern": ["III", "ICI", "III"],
  "key": {
    "I": "minecraft:iron_ingot",
    "C": "minecraft:chest"
  },
  "result": {"id": "hassountest:hassoun_iron_chest", "count": 1}
}
```


## `src/main/resources/fabric.mod.json`

```json
{
  "schemaVersion": 1,
  "id": "hassountest",
  "version": "${version}",
  "name": "Hassoun Test",
  "description": "A first Fabric mod project for Minecraft 1.21.1. Adds a 54-slot Hassoun Iron Chest.",
  "authors": ["Hassoun"],
  "license": "MIT",
  "environment": "*",
  "entrypoints": {
    "main": ["com.hassoun.test.HassounTest"],
    "client": ["com.hassoun.test.HassounTestClient"]
  },
  "depends": {
    "fabricloader": ">=0.16.5",
    "minecraft": "~1.21.1",
    "java": ">=21",
    "fabric-api": "*"
  }
}
```


## `build.gradle`

```groovy
plugins {
    id 'fabric-loom' version '1.7.4'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group

base {
    archivesName = project.archives_base_name
}

repositories { }

dependencies {
    minecraft "com.mojang:minecraft:${project.minecraft_version}"
    mappings "net.fabricmc:yarn:${project.yarn_mappings}:v2"
    modImplementation "net.fabricmc:fabric-loader:${project.loader_version}"
    modImplementation "net.fabricmc.fabric-api:fabric-api:${project.fabric_version}"
}

processResources {
    inputs.property 'version', project.version
    filesMatching('fabric.mod.json') { expand 'version': inputs.properties.version }
}

tasks.withType(JavaCompile).configureEach {
    options.release = 21
    options.encoding = 'UTF-8'
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
    withSourcesJar()
}

jar {
    from('LICENSE') { rename { "${it}_${project.base.archivesName.get()}" } }
}
```


## `settings.gradle`

```groovy
pluginManagement {
    repositories {
        maven { url = 'https://maven.fabricmc.net/' }
        gradlePluginPortal()
        mavenCentral()
    }
}
rootProject.name = 'HassounTest'
```


## `gradle.properties`

```properties
org.gradle.jvmargs=-Xmx2G
org.gradle.parallel=true
minecraft_version=1.21.1
yarn_mappings=1.21.1+build.3
loader_version=0.16.5
fabric_version=0.102.1+1.21.1
mod_version=1.0.0
maven_group=com.hassoun
archives_base_name=hassountest
```


## `gradle/wrapper/gradle-wrapper.properties`

```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.10.2-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```
