package com.hassoun.test;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public final class HassounTestClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HandledScreens.register(HassounTest.CHEST_SCREEN_HANDLER, HassounChestScreen::new);
    }
}
