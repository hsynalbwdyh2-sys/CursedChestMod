package com.hassoun.test;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

public class HassounChestScreenHandler extends ScreenHandler {
    private final Inventory inventory;

    public HassounChestScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, new net.minecraft.inventory.SimpleInventory(54));
    }

    public HassounChestScreenHandler(int syncId, PlayerInventory playerInventory, Inventory inventory) {
        super(HassounTest.CHEST_SCREEN_HANDLER, syncId);
        checkSize(inventory, 54);
        this.inventory = inventory;
        inventory.onOpen(playerInventory.player);
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 198));
        }
    }

    @Override public boolean canUse(PlayerEntity player) { return inventory.canPlayerUse(player); }

    @Override
    public net.minecraft.item.ItemStack quickMove(PlayerEntity player, int slotIndex) {
        net.minecraft.item.ItemStack newStack = net.minecraft.item.ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (slot != null && slot.hasStack()) {
            net.minecraft.item.ItemStack original = slot.getStack();
            newStack = original.copy();
            if (slotIndex < 54) {
                if (!insertItem(original, 54, slots.size(), true)) return net.minecraft.item.ItemStack.EMPTY;
            } else if (!insertItem(original, 0, 54, false)) {
                return net.minecraft.item.ItemStack.EMPTY;
            }
            if (original.isEmpty()) slot.setStack(net.minecraft.item.ItemStack.EMPTY);
            else slot.markDirty();
        }
        return newStack;
    }

    @Override public void onClosed(PlayerEntity player) { super.onClosed(player); inventory.onClose(player); }
}
