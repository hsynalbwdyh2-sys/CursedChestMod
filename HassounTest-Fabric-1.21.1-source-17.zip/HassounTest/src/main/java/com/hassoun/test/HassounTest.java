package com.hassoun.test;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HassounTest implements ModInitializer {
    public static final String MOD_ID = "hassountest";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final Block HASSoUN_IRON_CHEST = new HassounChestBlock(
            AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(3.0F).requiresTool()
    );
    public static BlockEntityType<HassounChestBlockEntity> CHEST_BLOCK_ENTITY;
    public static final net.minecraft.screen.ScreenHandlerType<HassounChestScreenHandler> CHEST_SCREEN_HANDLER =
            Registry.register(Registries.SCREEN_HANDLER, id("hassoun_chest"),
                    new net.minecraft.screen.ScreenHandlerType<>(HassounChestScreenHandler::new,
                            net.minecraft.resource.featuretoggle.FeatureFlags.VANILLA_FEATURES));

    @Override
    public void onInitialize() {
        Registry.register(Registries.BLOCK, id("hassoun_iron_chest"), HASSoUN_IRON_CHEST);
        Registry.register(Registries.ITEM, id("hassoun_iron_chest"),
                new BlockItem(HASSoUN_IRON_CHEST, new Item.Settings()));
        CHEST_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("hassoun_iron_chest"),
                BlockEntityType.Builder.create(HassounChestBlockEntity::new, HASSoUN_IRON_CHEST).build());
        LOGGER.info("Hassoun Test loaded: Hassoun Iron Chest registered.");
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
