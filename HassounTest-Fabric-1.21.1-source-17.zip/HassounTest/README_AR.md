# Hassoun Test — Fabric 1.21.1

مود تجريبي لماينكرافت Java 1.21.1 باستخدام Java 21 وFabric Loader وFabric API. يضيف صندوق حسون بسعة 54 خانة مع واجهة تخزين وحفظ للمحتويات ووصفة تصنيع.

## محتويات المشروع
- `src/main/java/`: ملفات Java الخاصة بالمود.
- `src/main/resources/fabric.mod.json`: تعريف المود واعتمادياته ونقاط الدخول.
- `src/main/resources/assets/`: أسماء العرض ونماذج البلوك والآيتم.
- `src/main/resources/data/`: وصفة التصنيع وملف إسقاط البلوك.
- `build.gradle`, `settings.gradle`, `gradle.properties`: إعدادات البناء وإصدارات Minecraft/Fabric.

## بناء ملف JAR
1. استخدم بيئة فيها **JDK 21** و**Gradle 8.10.2** أو افتح المشروع في IDE يدعم Gradle.
2. من مجلد المشروع الذي يحتوي `build.gradle` نفّذ: `gradle build`
3. بعد نجاح البناء، ستجد ملف المود في `build/libs/`، عادةً `hassountest-1.0.0.jar`.
4. انسخ ملف JAR إلى مجلد `mods` في مجلد لعبة Minecraft 1.21.1، وثبّت نسخة Fabric Loader المتوافقة وFabric API.

## ملاحظة مهمة
هذه ملفات مصدر مشروع، وليست ملف JAR مبنياً. لم يتم تنفيذ Gradle build أو اختبار التشغيل هنا، لذلك يجب البناء وفحص سجل الأخطاء قبل اعتبار المود متحققاً منه. يحتاج البناء إلى اتصال لتنزيل اعتماديات Gradle/Minecraft إذا لم تكن مخزنة مسبقاً.
